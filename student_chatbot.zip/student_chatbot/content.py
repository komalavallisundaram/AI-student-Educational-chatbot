import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer

input_file = r"C:\Users\shenbagam\videos\apanaa\QA_cleaned_unique.csv"
output_embeddings_csv = r"C:/Users/shenbagam/videos/apanaa/question_embeddings.csv"

try:
    df = pd.read_csv(input_file, quotechar='"', encoding="utf-8")
except pd.errors.ParserError:
    print("⚠️ ParserError detected. Retrying with python engine...")
    df = pd.read_csv(input_file, quotechar='"', encoding="utf-8", engine="python")

df.columns = df.columns.str.strip().str.lower().str.replace("?", "").str.replace(" ", "_")

if 'question' not in df.columns or 'answer' not in df.columns:
    raise ValueError(f"❌ Expected 'question' and 'answer' columns, but got: {df.columns.tolist()}")

df['question'] = df['question'].fillna('').astype(str).str.strip().str.replace('"', '')
df['answer'] = df['answer'].fillna('').astype(str).str.strip().str.replace('"', '')

df = df[(df['question'] != "") & (df['answer'] != "")]
df = df.drop_duplicates(subset=['question'])

model = SentenceTransformer('paraphrase-MiniLM-L3-v2')
questions = df['question'].tolist()
embeddings = model.encode(questions, convert_to_numpy=True)

embeddings_df = pd.DataFrame(embeddings)
embeddings_df.insert(0, "Question", questions)
embeddings_df.insert(1, "Answer", df['answer'].tolist())
embeddings_df.to_csv(output_embeddings_csv, index=False)

print("✅ Embeddings generated and saved as CSV:", output_embeddings_csv)
